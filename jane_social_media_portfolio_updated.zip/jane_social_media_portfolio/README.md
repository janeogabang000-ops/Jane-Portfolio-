# Mary Jane Ogabang — Creative Portfolio

A responsive, single-page portfolio website for graphic design, social media content, and writing.

## Before publishing
1. Open `index.html` and replace `ADD-YOUR-EMAIL@example.com` with your real email address.
2. Replace `ADD-YOUR-LINKEDIN-URL` with your LinkedIn profile URL.
3. Review every skill statement and edit anything that doesn't reflect your actual ability.
4. Add your own design exports and CapCut samples when available. The included designs and captions are clearly labeled as concept work.

## Publish with GitHub Pages
1. Sign in to GitHub and create a **public** repository (for example, `jane-creative-portfolio`).
2. Upload `index.html` and this README to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for deployment and use the site URL shown in Settings → Pages.

GitHub's official guide: https://docs.github.com/en/pages/quickstart

Note: the website is not live until you publish it from your own GitHub account.
